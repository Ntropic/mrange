# -*- coding: utf-8 -*-

from mrange.mrange import *